package com.example.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val BeautifulDarkColorScheme = darkColorScheme(
    primary = AccentPurple,
    onPrimary = BackgroundDark,
    secondary = InteractiveDark,
    onSecondary = TextLight,
    tertiary = AccentPurpleDark,
    background = BackgroundDark,
    onBackground = TextLight,
    surface = SurfaceDark,
    onSurface = TextLight,
    surfaceVariant = CardDark,
    onSurfaceVariant = TextLight,
    outline = BorderDark,
    outlineVariant = BorderMedium,
    error = Color(0xFFE57373),
    onError = Color(0xFF2C0B0B),
    errorContainer = Color(0xFF2C1C1C),
    onErrorContainer = Color(0xFFE57373)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    // Disable system dynamic color by default to strictly enforce the "Elegant Dark" branding
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        else -> BeautifulDarkColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
