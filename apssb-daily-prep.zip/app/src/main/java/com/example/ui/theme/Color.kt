package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Palette Colours
val BackgroundDark = Color(0xFF0D0D0D)
val SurfaceDark = Color(0xFF121212)
val CardDark = Color(0xFF1E1E1E)
val InteractiveDark = Color(0xFF252525)

// Accents
val AccentPurple = Color(0xFFBB86FC)
val AccentPurpleDark = Color(0xFF3700B3)
val BorderDark = Color(0xFF2A2A2A)
val BorderMedium = Color(0xFF333333)

val TextLight = Color(0xFFE5E5E5)
val TextMuted = Color(0xFF8A8A8A)
val TextPurple = Color(0xFFB388FF)
