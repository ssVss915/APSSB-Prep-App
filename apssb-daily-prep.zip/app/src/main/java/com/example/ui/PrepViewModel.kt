package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.DailyQuestionSetEntity
import com.example.data.local.TestResultEntity
import com.example.data.model.Question
import com.example.data.repository.PrepRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

sealed interface QuestionsUiState {
    object Idle : QuestionsUiState
    object Loading : QuestionsUiState
    data class Success(val questions: List<Question>) : QuestionsUiState
    data class Error(val message: String) : QuestionsUiState
}

class PrepViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PrepRepository.getInstance(application)

    // Format: YYYY-MM-DD
    private val _selectedDate = MutableStateFlow(getTodayString())
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _questionsState = MutableStateFlow<QuestionsUiState>(QuestionsUiState.Idle)
    val questionsState: StateFlow<QuestionsUiState> = _questionsState.asStateFlow()

    // Test responses: key = questionIndex, value = selectedOptionIndex
    private val _testAnswers = MutableStateFlow<Map<Int, Int>>(emptyMap())
    val testAnswers: StateFlow<Map<Int, Int>> = _testAnswers.asStateFlow()

    // Is the user actively taking a test for the selected date?
    private val _isShowingTest = MutableStateFlow(false)
    val isShowingTest: StateFlow<Boolean> = _isShowingTest.asStateFlow()

    // Revealed answers in Study/Learning Mode: key = questionIndex, value = Boolean (unhidden)
    private val _unhiddenAnswers = MutableStateFlow<Map<Int, Boolean>>(emptyMap())
    val unhiddenAnswers: StateFlow<Map<Int, Boolean>> = _unhiddenAnswers.asStateFlow()

    // All test results and general generated question dates for calendar rendering
    val allTestResults: StateFlow<List<TestResultEntity>> = repository.getAllTestResults()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allQuestionSets: StateFlow<List<DailyQuestionSetEntity>> = repository.getAllQuestionSets()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Direct access to the test result for the currently selected date
    val currentTestResult: StateFlow<TestResultEntity?> = combine(selectedDate, repository.getAllTestResults()) { date, results ->
        results.find { it.date == date }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        loadQuestionsForDate(getTodayString())
    }

    fun selectDate(date: String) {
        _selectedDate.value = date
        _testAnswers.value = emptyMap()
        _unhiddenAnswers.value = emptyMap()
        _isShowingTest.value = false
        loadQuestionsForDate(date)
    }

    fun forceRefreshQuestions() {
        _isShowingTest.value = false
        _testAnswers.value = emptyMap()
        _unhiddenAnswers.value = emptyMap()
        loadQuestionsForDate(_selectedDate.value, forceRefresh = true)
    }

    private fun loadQuestionsForDate(date: String, forceRefresh: Boolean = false) {
        viewModelScope.launch {
            _questionsState.value = QuestionsUiState.Loading
            try {
                val questions = repository.getQuestionsForDate(date, forceRefresh)
                if (questions.isNotEmpty()) {
                    _questionsState.value = QuestionsUiState.Success(questions)
                } else {
                    _questionsState.value = QuestionsUiState.Error("No questions found for this date. Check your Internet connection or try refreshing!")
                }
            } catch (e: Exception) {
                _questionsState.value = QuestionsUiState.Error(e.localizedMessage ?: "Unknown error while fetching questions")
            }
        }
    }

    fun selectTestAnswer(questionIndex: Int, optionIndex: Int) {
        val currentAnswers = _testAnswers.value.toMutableMap()
        currentAnswers[questionIndex] = optionIndex
        _testAnswers.value = currentAnswers
    }

    fun toggleUnhideAnswer(questionIndex: Int) {
        val currentRevealed = _unhiddenAnswers.value.toMutableMap()
        val isRevealed = currentRevealed[questionIndex] ?: false
        currentRevealed[questionIndex] = !isRevealed
        _unhiddenAnswers.value = currentRevealed
    }

    fun revealAllAnswers(size: Int) {
        val current = mutableMapOf<Int, Boolean>()
        for (i in 0 until size) {
            current[i] = true
        }
        _unhiddenAnswers.value = current
    }

    fun hideAllAnswers() {
        _unhiddenAnswers.value = emptyMap()
    }

    fun startTestMode() {
        _isShowingTest.value = true
        _testAnswers.value = emptyMap()
    }

    fun exitTestMode() {
        _isShowingTest.value = false
        _testAnswers.value = emptyMap()
    }

    fun submitTest(questions: List<Question>) {
        val date = _selectedDate.value
        val answers = _testAnswers.value
        var correctCount = 0
        val selectedList = ArrayList<Int>()

        questions.forEachIndexed { index, question ->
            val selected = answers[index] ?: -1
            selectedList.add(selected)
            if (selected == question.correctOptionIndex) {
                correctCount++
            }
        }

        viewModelScope.launch {
            repository.saveTestResult(
                date = date,
                score = correctCount,
                totalQuestions = questions.size,
                selectedAnswers = selectedList
            )
            // Show score/results panel, which is triggered by currentTestResult flow
            _isShowingTest.value = false
        }
    }

    fun retakeTest() {
        viewModelScope.launch {
            repository.deleteTestResult(_selectedDate.value)
            startTestMode()
        }
    }

    companion object {
        fun getTodayString(): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            return sdf.format(Date())
        }
    }
}
