package com.example

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.DailyQuestionSetEntity
import com.example.data.local.TestResultEntity
import com.example.data.model.Question
import com.example.ui.PrepViewModel
import com.example.ui.QuestionsUiState
import com.example.ui.components.PrepCalendar
import com.example.ui.components.formatPrettyDate
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    APSSBPrepApp(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun APSSBPrepApp(
    modifier: Modifier = Modifier,
    viewModel: PrepViewModel = viewModel()
) {
    val context = LocalContext.current
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val questionsState by viewModel.questionsState.collectAsStateWithLifecycle()
    val isShowingTest by viewModel.isShowingTest.collectAsStateWithLifecycle()
    val testAnswers by viewModel.testAnswers.collectAsStateWithLifecycle()
    val unhiddenAnswers by viewModel.unhiddenAnswers.collectAsStateWithLifecycle()
    val currentTestResult by viewModel.currentTestResult.collectAsStateWithLifecycle()
    val allQuestionSets by viewModel.allQuestionSets.collectAsStateWithLifecycle()
    val allTestResults by viewModel.allTestResults.collectAsStateWithLifecycle()

    var showConfirmSubmitDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // High fidelity elegant top bar navigation matching our design theme
        TopAppBar(
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color(0xFFBB86FC), Color(0xFF3700B3))
                                )
                            )
                    ) {
                        Text(
                            text = "A",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "APSSB Master",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            lineHeight = 16.sp
                        )
                        Text(
                            text = "AI PREP SUITE 2026",
                            fontSize = 8.sp,
                            color = Color(0xFFBB86FC),
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.6.sp
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface,
                titleContentColor = Color.White,
                actionIconContentColor = Color(0xFFBB86FC)
            ),
            actions = {
                IconButton(onClick = { viewModel.forceRefreshQuestions() }) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Generate Dynamic Question Package"
                    )
                }
            }
        )
        // Elegant border line beneath header
        Divider(color = MaterialTheme.colorScheme.outline, thickness = 1.dp)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // responsive outer boundaries
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 680.dp)
                ) {
                    // Custom Integrated Calendar
                    PrepCalendar(
                        selectedDate = selectedDate,
                        allQuestionSets = allQuestionSets,
                        allTestResults = allTestResults,
                        onDateSelected = { date ->
                            viewModel.selectDate(date)
                        },
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }

            // state management switches
            when (val state = questionsState) {
                is QuestionsUiState.Loading -> {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "Generating Exam Questions...",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )
                            CircularProgressIndicator(
                                modifier = Modifier.size(46.dp),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                "Sourcing high-yield questions, previous GK keys, and custom syllabus solutions from APSSB timelines (2015-2026) using Gemini...",
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                        }
                    }
                }

                is QuestionsUiState.Error -> {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Error Logo",
                                        tint = MaterialTheme.colorScheme.onErrorContainer
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "Generation Halted",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    state.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { viewModel.forceRefreshQuestions() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.error
                                    )
                                ) {
                                    Text("Retry Gemini Sourcing")
                                }
                            }
                        }
                    }
                }

                is QuestionsUiState.Success -> {
                    val questions = state.questions

                    // Daily Goals tracker matching design goals
                    item {
                        val completedCount = if (currentTestResult != null) questions.size else unhiddenAnswers.filterValues { it }.size
                        ProgressBarItem(
                            completed = completedCount,
                            target = questions.size
                        )
                    }

                    // control deck layout
                    item {
                        ControlDeck(
                            date = selectedDate,
                            questionsCount = questions.size,
                            isAttempted = currentTestResult != null,
                            testResult = currentTestResult,
                            isShowingTest = isShowingTest,
                            onStudyClick = { viewModel.exitTestMode() },
                            onTestClick = { viewModel.startTestMode() },
                            onRetakeClick = { viewModel.retakeTest() },
                            onRevealAll = { viewModel.revealAllAnswers(questions.size) },
                            onHideAll = { viewModel.hideAllAnswers() }
                        )
                    }

                    if (isShowingTest) {
                        // active Practice Exam Mode
                        itemsIndexed(questions) { qIndex, question ->
                            QuestionTestCard(
                                questionIndex = qIndex,
                                question = question,
                                selectedChoiceIndex = testAnswers[qIndex],
                                onChoiceChosen = { choice ->
                                    viewModel.selectTestAnswer(qIndex, choice)
                                }
                            )
                        }

                        item {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    if (testAnswers.size < questions.size) {
                                        Toast.makeText(
                                            context,
                                            "You answered ${testAnswers.size} of ${questions.size} questions. Please complete all of them!",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                    showConfirmSubmitDialog = true
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .padding(bottom = 16.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Submit Exam")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Submit My Responses", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                        }
                    } else if (currentTestResult != null) {
                        // Render previous completed exams details
                        val testResult = currentTestResult!!
                        item {
                            ScoreboardCard(testResult = testResult)
                        }

                        item {
                            Text(
                                "Detailed Graded Review",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                            )
                        }

                        itemsIndexed(questions) { qIndex, question ->
                            val userChoice = testResult.selectedAnswers.getOrNull(qIndex) ?: -1
                            GradedReviewCard(
                                questionIndex = qIndex,
                                question = question,
                                userChoiceIndex = userChoice
                            )
                        }
                    } else {
                        // Regular Flashcard reading mode
                        itemsIndexed(questions) { qIndex, question ->
                            val isUnhidden = unhiddenAnswers[qIndex] ?: false
                            FlashcardStudyCard(
                                questionIndex = qIndex,
                                question = question,
                                isUnhidden = isUnhidden,
                                onToggleReveal = { viewModel.toggleUnhideAnswer(qIndex) }
                            )
                        }
                    }
                }
                else -> {}
            }
        }
    }

    if (showConfirmSubmitDialog) {
        val successState = questionsState as? QuestionsUiState.Success
        val questions = successState?.questions ?: emptyList()
        val missed = questions.size - testAnswers.size

        AlertDialog(
            onDismissRequest = { showConfirmSubmitDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Confirmation",
                        modifier = Modifier.padding(end = 6.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text("Submit Practice Exam?", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text(
                    if (missed > 0) "Warning: You left $missed questions unanswered! Are you sure you want to finalize now and view your grade?"
                    else "Ready to grade your test? This will record your marks for ${formatPrettyDate(selectedDate)} in the calendar record."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConfirmSubmitDialog = false
                        viewModel.submitTest(questions)
                    }
                ) {
                    Text("Yes, Grade Now", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmSubmitDialog = false }) {
                    Text("Go Back")
                }
            }
        )
    }
}

@Composable
fun ControlDeck(
    date: String,
    questionsCount: Int,
    isAttempted: Boolean,
    testResult: TestResultEntity?,
    isShowingTest: Boolean,
    onStudyClick: () -> Unit,
    onTestClick: () -> Unit,
    onRetakeClick: () -> Unit,
    onRevealAll: () -> Unit,
    onHideAll: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isShowingTest) "📝 Practice Exam Mode" else "💡 Study & Flashcard Mode",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
                
                if (!isShowingTest && !isAttempted) {
                    Row {
                        TextButton(onClick = onRevealAll) {
                            Text("Reveal All", style = MaterialTheme.typography.labelSmall)
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        TextButton(onClick = onHideAll) {
                            Text("Hide All", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "We have compiled $questionsCount real and repeated APSSB MCQs spanning General English, Arithmetic, Science, Social Sciences, and Arunachal GK.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
            )

            if (isAttempted && testResult != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Color(0xFFE8F5E9), 
                            shape = RoundedCornerShape(8.dp)
                        )
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Completed logo",
                        tint = Color(0xFF2E7D32),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Tested: ${testResult.score}/${testResult.totalQuestions} Correct (${(testResult.score.toFloat() / testResult.totalQuestions * 100).toInt()}%)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1B5E20)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (isShowingTest) {
                    OutlinedButton(
                        onClick = onStudyClick,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.List, contentDescription = "Study")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reading Mode")
                    }
                } else if (isAttempted) {
                    Button(
                        onClick = onRetakeClick,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Retake")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Retake Test")
                    }
                    
                    OutlinedButton(
                        onClick = onStudyClick,
                        modifier = Modifier.weight(1.2f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.List, contentDescription = "View Cards")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Review Flashcards")
                    }
                } else {
                    Button(
                        onClick = onTestClick,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Start Test")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Take a Test")
                    }
                }
            }
        }
    }
}

@Composable
fun FlashcardStudyCard(
    questionIndex: Int,
    question: Question,
    isUnhidden: Boolean,
    onToggleReveal: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SubjectBadge(subject = question.subject)
                Text(
                    text = "APSSB ${question.year}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "${questionIndex + 1}. ${question.question}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                question.options.forEachIndexed { optIndex, optionString ->
                    val isCorrectIdx = optIndex == question.correctOptionIndex
                    val isRevealedCorrect = isUnhidden && isCorrectIdx
                    val containerColor = if (isRevealedCorrect) Color(0x184CAF50) else Color(0xFF252525)
                    val borderColor = if (isRevealedCorrect) Color(0xFF4CAF50) else Color(0xFF333333)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(containerColor, shape = RoundedCornerShape(12.dp))
                            .border(
                                width = 1.dp,
                                color = borderColor,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onToggleReveal() }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${(65 + optIndex).toChar()}.",
                            fontWeight = FontWeight.Bold,
                            color = if (isRevealedCorrect) Color(0xFF81C784) 
                                    else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.width(24.dp)
                        )
                        Text(
                            text = optionString,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isRevealedCorrect) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onToggleReveal,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isUnhidden) MaterialTheme.colorScheme.secondary 
                                    else MaterialTheme.colorScheme.primaryContainer,
                    contentColor = if (isUnhidden) MaterialTheme.colorScheme.onSecondary 
                                   else MaterialTheme.colorScheme.onPrimaryContainer
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                Icon(
                    imageVector = if (isUnhidden) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isUnhidden) "Hide Solution" else "Unhide Correct Answer & Explanation",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            AnimatedVisibility(visible = isUnhidden) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .border(
                            BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Correct Solution",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Correct Answer: Option ${(65 + question.correctOptionIndex).toChar()}",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = question.options[question.correctOptionIndex],
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(start = 26.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Detailed APSSB Syllabus Context:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = question.explanation,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
fun QuestionTestCard(
    questionIndex: Int,
    question: Question,
    selectedChoiceIndex: Int?,
    onChoiceChosen: (Int) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SubjectBadge(subject = question.subject)
                Text(
                    text = "APSSB Mock Year: ${question.year}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "${questionIndex + 1}. ${question.question}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(14.dp))

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                question.options.forEachIndexed { optIndex, optionString ->
                    val isChecked = selectedChoiceIndex == optIndex
                    val containerColor = if (isChecked) Color(0x1EBB86FC) else Color(0xFF252525)
                    val borderColor = if (isChecked) MaterialTheme.colorScheme.primary else Color(0xFF333333)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(containerColor, shape = RoundedCornerShape(12.dp))
                            .border(1.dp, borderColor, shape = RoundedCornerShape(12.dp))
                            .clickable { onChoiceChosen(optIndex) }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isChecked,
                            onClick = { onChoiceChosen(optIndex) },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = MaterialTheme.colorScheme.primary,
                                unselectedColor = Color(0xFF8A8A8A)
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = optionString,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isChecked) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ScoreboardCard(testResult: TestResultEntity) {
    val percentage = (testResult.score.toFloat() / testResult.totalQuestions * 100).toInt()
    val themeColor = when {
        percentage >= 90 -> Color(0xFF2E7D32)
        percentage >= 60 -> Color(0xFFF57C00)
        else -> Color(0xFFD32F2F)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = themeColor.copy(alpha = 0.1f)),
        border = BorderStroke(1.dp, themeColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "TEST FINISHED STATUS",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelMedium,
                color = themeColor
            )
            Spacer(modifier = Modifier.height(10.dp))

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(90.dp)
                    .background(themeColor.copy(alpha = 0.15f), shape = CircleShape)
                    .border(2.dp, themeColor, shape = CircleShape)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$percentage%",
                        fontWeight = FontWeight.Black,
                        fontSize = 24.sp,
                        color = themeColor
                    )
                    Text(
                        text = "Marks",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "${testResult.score} Correct  •  ${testResult.totalQuestions - testResult.score} Incorrect",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = when {
                    percentage >= 100 -> "🏆 Flawless 100% Score! You are perfectly poised to conquer the APSSB exam ranks."
                    percentage >= 85 -> "🔥 Outstanding! Your grasp is exceptional. Top LDC/UDC rank list incoming!"
                    percentage >= 60 -> "👍 Nice Job! Review your minor omissions below to score even higher next run."
                    else -> "📚 Review required. Re-read the flashcard explanations below and try retaking the test!"
                },
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        }
    }
}

@Composable
fun GradedReviewCard(
    questionIndex: Int,
    question: Question,
    userChoiceIndex: Int
) {
    val isCorrect = userChoiceIndex == question.correctOptionIndex

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = 1.dp,
            color = if (isCorrect) Color(0xFF4CAF50).copy(alpha = 0.5f) 
                    else Color(0xFFE57373).copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SubjectBadge(subject = question.subject)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isCorrect) "CORRECT" else "INCORRECT",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isCorrect) Color(0xFF2E7D32) else Color(0xFFC62828),
                        modifier = Modifier
                            .background(
                                color = if (isCorrect) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "${questionIndex + 1}. ${question.question}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(12.dp))

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                question.options.forEachIndexed { optIndex, optionString ->
                    val isKeyOption = optIndex == question.correctOptionIndex
                    val isUserSelection = optIndex == userChoiceIndex

                    val containerColor = when {
                        isKeyOption -> Color(0x184CAF50)
                        isUserSelection && !isKeyOption -> Color(0x18E57373)
                        else -> Color(0xFF252525)
                    }

                    val borderColor = when {
                        isKeyOption -> Color(0xFF4CAF50)
                        isUserSelection && !isKeyOption -> Color(0xFFE57373)
                        else -> Color(0xFF333333)
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(containerColor, shape = RoundedCornerShape(12.dp))
                            .border(1.dp, borderColor, shape = RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${(65 + optIndex).toChar()}.",
                            fontWeight = FontWeight.Bold,
                            color = when {
                                isKeyOption -> Color(0xFF81C784)
                                isUserSelection && !isKeyOption -> Color(0xFFE57373)
                                else -> MaterialTheme.colorScheme.primary
                            },
                            modifier = Modifier.width(24.dp)
                        )
                        Text(
                            text = optionString,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isKeyOption) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        
                        when {
                            isKeyOption -> {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Correct key option",
                                    tint = Color(0xFF4CAF50)
                                )
                            }
                            isUserSelection && !isKeyOption -> {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Incorrect selection",
                                    tint = Color(0xFFE57373)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    .border(
                        BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
                        shape = RoundedCornerShape(10.dp)
                    )
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Explain key info",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Official APSSB Question Explanation",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = question.explanation,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun SubjectBadge(subject: String) {
    val badgeColor = when (subject) {
        "Arunachal GK" -> Color(0xFF4CAF50)
        "Mathematics" -> Color(0xFF9C27B0)
        "Science" -> Color(0xFF03A9F4)
        "English" -> Color(0xFFFF9800)
        "Social Science" -> Color(0xFF795548)
        else -> MaterialTheme.colorScheme.primary
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(badgeColor.copy(alpha = 0.13f), shape = RoundedCornerShape(50.dp))
            .border(1.dp, badgeColor.copy(alpha = 0.4f), shape = RoundedCornerShape(50.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Star,
            contentDescription = null,
            tint = badgeColor,
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = subject,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = badgeColor
        )
    }
}

@Composable
fun ProgressBarItem(completed: Int, target: Int, modifier: Modifier = Modifier) {
    val progress = if (target > 0) completed.toFloat() / target else 0f
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp, horizontal = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "DAILY STUDY PROGRESS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFBB86FC),
                    letterSpacing = 1.2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = "$completed",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "/ $target questions prepared",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
            }
            
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(54.dp)
                    .background(Color(0xFF1E1E1E), shape = CircleShape)
                    .border(2.dp, Color(0xFF2A2A2A), shape = CircleShape)
            ) {
                CircularProgressIndicator(
                    progress = progress.coerceIn(0f, 1f),
                    color = Color(0xFFBB86FC),
                    strokeWidth = 4.dp,
                    trackColor = Color(0xFF121212),
                    modifier = Modifier.fillMaxSize().padding(3.dp)
                )
                Text(
                    text = "${(progress * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }
    }
}
