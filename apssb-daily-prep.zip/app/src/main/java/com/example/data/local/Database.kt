package com.example.data.local

import androidx.room.*
import com.example.data.model.Question
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "daily_question_sets")
data class DailyQuestionSetEntity(
    @PrimaryKey val date: String, // format "YYYY-MM-DD"
    val questions: List<Question>,
    val createdTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "test_results")
data class TestResultEntity(
    @PrimaryKey val date: String, // format "YYYY-MM-DD"
    val score: Int,
    val totalQuestions: Int,
    val selectedAnswers: List<Int>, // 0-based indices corresponding to questions
    val completedTimestamp: Long = System.currentTimeMillis()
)

class Converters {
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    @TypeConverter
    fun fromQuestionList(value: List<Question>?): String? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, Question::class.java)
        return moshi.adapter<List<Question>>(type).toJson(value)
    }

    @TypeConverter
    fun toQuestionList(value: String?): List<Question>? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, Question::class.java)
        return moshi.adapter<List<Question>>(type).fromJson(value)
    }

    @TypeConverter
    fun fromIntList(value: List<Int>?): String? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, Integer::class.java)
        return moshi.adapter<List<Int>>(type).toJson(value)
    }

    @TypeConverter
    fun toIntList(value: String?): List<Int>? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, Integer::class.java)
        return moshi.adapter<List<Int>>(type).fromJson(value)
    }
}

@Dao
interface PrepDao {
    @Query("SELECT * FROM daily_question_sets WHERE date = :date LIMIT 1")
    suspend fun getQuestionSetForDate(date: String): DailyQuestionSetEntity?

    @Query("SELECT * FROM daily_question_sets")
    fun getAllQuestionSets(): Flow<List<DailyQuestionSetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestionSet(set: DailyQuestionSetEntity)

    @Query("SELECT * FROM test_results WHERE date = :date LIMIT 1")
    fun getTestResultForDate(date: String): Flow<TestResultEntity?>

    @Query("SELECT * FROM test_results")
    fun getAllTestResults(): Flow<List<TestResultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTestResult(result: TestResultEntity)

    @Query("DELETE FROM test_results WHERE date = :date")
    suspend fun deleteTestResultForDate(date: String)
}

@Database(entities = [DailyQuestionSetEntity::class, TestResultEntity::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun prepDao(): PrepDao
}
