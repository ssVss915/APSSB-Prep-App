package com.example.data.repository

import android.content.Context
import androidx.room.Room
import com.example.data.api.GeminiService
import com.example.data.local.AppDatabase
import com.example.data.local.DailyQuestionSetEntity
import com.example.data.local.TestResultEntity
import com.example.data.model.Question
import kotlinx.coroutines.flow.Flow

class PrepRepository private constructor(private val database: AppDatabase) {
    private val dao = database.prepDao()

    suspend fun getQuestionsForDate(date: String, forceRefresh: Boolean = false): List<Question> {
        if (!forceRefresh) {
            val cached = dao.getQuestionSetForDate(date)
            if (cached != null && cached.questions.size >= 100) {
                return cached.questions
            }
        }
        val generated = GeminiService.generateDailyQuestions(date)
        if (generated.isNotEmpty()) {
            dao.insertQuestionSet(DailyQuestionSetEntity(date, generated))
        }
        return generated
    }

    suspend fun saveTestResult(date: String, score: Int, totalQuestions: Int, selectedAnswers: List<Int>) {
        dao.insertTestResult(TestResultEntity(date, score, totalQuestions, selectedAnswers))
    }

    suspend fun deleteTestResult(date: String) {
        dao.deleteTestResultForDate(date)
    }

    fun getTestResult(date: String): Flow<TestResultEntity?> {
        return dao.getTestResultForDate(date)
    }

    fun getAllTestResults(): Flow<List<TestResultEntity>> {
        return dao.getAllTestResults()
    }

    fun getAllQuestionSets(): Flow<List<DailyQuestionSetEntity>> {
        return dao.getAllQuestionSets()
    }

    companion object {
        @Volatile
        private var INSTANCE: PrepRepository? = null

        fun getInstance(context: Context): PrepRepository {
            return INSTANCE ?: synchronized(this) {
                val database = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "apssb_prep_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                PrepRepository(database).also { INSTANCE = it }
            }
        }
    }
}
